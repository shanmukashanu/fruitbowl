import React, { useState, useEffect } from 'react';
import { Award, Users, Phone, Sparkles, Heart } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface LuckyFarmer {
  id: string;
  name: string;
  image_url: string;
  content: string;
  phone: string | null;
}

interface LuckySubscriber {
  id: string;
  name: string;
  image_url: string;
  content: string;
  phone: string | null;
}

const LuckyPage: React.FC = () => {
  const [farmers, setFarmers] = useState<LuckyFarmer[]>([]);
  const [subscribers, setSubscribers] = useState<LuckySubscriber[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const [farmersRes, subscribersRes] = await Promise.all([
      supabase.from('lucky_farmers').select('*').order('created_at', { ascending: false }),
      supabase.from('lucky_subscribers').select('*').order('created_at', { ascending: false }),
    ]);
    if (farmersRes.data) setFarmers(farmersRes.data);
    if (subscribersRes.data) setSubscribers(subscribersRes.data);
    setLoading(false);
  };

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="bg-gradient-to-br from-orange-500 via-orange-600 to-orange-700 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full"></div>
          <div className="absolute bottom-10 right-10 w-32 h-32 bg-white/10 rounded-full"></div>
          <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-white/10 rounded-full"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <div className="inline-flex items-center space-x-2 bg-white/20 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Sparkles className="h-4 w-4" />
              <span>Lucky Winners</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              Our Lucky Stars
            </h1>
            <p className="text-xl text-orange-100 leading-relaxed max-w-2xl mx-auto">
              Celebrating our amazing farmers and loyal subscribers who make Annadata special.
            </p>
          </div>
        </div>
      </section>

      {loading ? (
        <div className="text-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      ) : (
        <>
          {/* Lucky Farmers */}
          <section className="py-20 bg-gradient-to-b from-white to-green-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-6">
                  <Award className="h-8 w-8 text-green-600" />
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                  Lucky Farmers
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  These hardworking farmers are the backbone of Annadata. We're proud to partner with them.
                </p>
              </div>

              {farmers.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600">No lucky farmers featured yet.</p>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {farmers.map((farmer) => (
                    <div
                      key={farmer.id}
                      className="bg-white rounded-3xl shadow-xl overflow-hidden hover:shadow-2xl transition-all group"
                    >
                      <div className="aspect-square overflow-hidden relative">
                        <img
                          src={farmer.image_url || 'https://images.unsplash.com/photo-1605000797499-95a51c5269ae?w=400'}
                          alt={farmer.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute top-4 right-4 bg-green-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                          Farmer
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="text-xl font-bold text-gray-900 mb-2">{farmer.name}</h3>
                        <p className="text-gray-600 mb-4">{farmer.content}</p>
                        {farmer.phone && (
                          <a
                            href={`tel:${farmer.phone}`}
                            className="inline-flex items-center space-x-2 text-green-600 hover:text-green-700 font-medium"
                          >
                            <Phone className="h-4 w-4" />
                            <span>{farmer.phone}</span>
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>

          {/* Lucky Subscribers */}
          <section className="py-20 bg-gradient-to-b from-green-50 to-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-orange-100 rounded-full mb-6">
                  <Heart className="h-8 w-8 text-orange-600" />
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                  Lucky Subscribers
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Our loyal customers who won exciting prizes through our lucky draws and referral programs.
                </p>
              </div>

              {subscribers.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600">No lucky subscribers featured yet.</p>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {subscribers.map((subscriber) => (
                    <div
                      key={subscriber.id}
                      className="bg-white rounded-3xl shadow-xl overflow-hidden hover:shadow-2xl transition-all group"
                    >
                      <div className="aspect-square overflow-hidden relative">
                        <img
                          src={subscriber.image_url || 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400'}
                          alt={subscriber.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute top-4 right-4 bg-orange-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                          Winner
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="text-xl font-bold text-gray-900 mb-2">{subscriber.name}</h3>
                        <p className="text-gray-600 mb-4">{subscriber.content}</p>
                        {subscriber.phone && (
                          <a
                            href={`tel:${subscriber.phone}`}
                            className="inline-flex items-center space-x-2 text-orange-600 hover:text-orange-700 font-medium"
                          >
                            <Phone className="h-4 w-4" />
                            <span>{subscriber.phone}</span>
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        </>
      )}

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-green-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Want to Be Our Next Lucky Winner?
          </h2>
          <p className="text-green-100 text-lg mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter and participate in our monthly lucky draws for a chance to win exciting prizes!
          </p>
          <form className="max-w-md mx-auto flex">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-6 py-4 rounded-l-full focus:outline-none"
            />
            <button
              type="submit"
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-r-full font-semibold transition-colors"
            >
              Join Now
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default LuckyPage;
